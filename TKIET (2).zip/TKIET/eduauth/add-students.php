<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');

if (isset($_POST['submit'])) {
    $stuname = $_POST['stuname'];
    $stuemail = $_POST['stuemail'];
    $stuclass = $_POST['stuclass'];
    $gender = $_POST['gender'];
    $bd = $_POST['bd'];
    $dob = $_POST['dob'];
    $stuid = $_POST['stuid'];
    $fname = $_POST['fname'];
    $mname = $_POST['mname'];
    $connum = $_POST['connum'];
    $altconnum = $_POST['altconnum'];
    $address = $_POST['address'];
    $uname = $_POST['uname'];
    $password = md5($_POST['password']);
    $image = $_FILES["image"]["name"];
    $cty = $_POST['cty'];
    $pc = $_POST['pc'];
    $state = $_POST['state'];
    $ctr = $_POST['ctr'];
    $poy = $_POST['poy'];
    $dpt = $_POST['dpt'];
    
    $tcl = $_POST['tcl'];
    $cc = $_POST['cc'];
    $role = $_POST['role'];
    $areYouPlaced = $_POST['areYouPlaced'];

    $ret = "select UserName from tblstudent where UserName=:uname || StuID=:stuid";
    $query = $dbh->prepare($ret);
    $query->bindParam(':uname', $uname, PDO::PARAM_STR);
    $query->bindParam(':stuid', $stuid, PDO::PARAM_STR);
    $query->execute();
    $results = $query->fetchAll(PDO::FETCH_OBJ);
    if ($query->rowCount() == 0) {
        $extension = substr($image, strlen($image) - 4, strlen($image));
        $allowed_extensions = array(".jpg", "jpeg", ".png", ".gif");
        if (!empty($image) && !in_array($extension, $allowed_extensions)) {
            echo "<script>alert('Image has Invalid format. Only jpg / jpeg/ png /gif format allowed');</script>";
        } else {
            if (!empty($image)) {
                $image = $stuid . $extension;
                // Path to the "images" folder
$imagesFolder = __DIR__ . DIRECTORY_SEPARATOR . 'TKIET\eduauth\assets\images' . DIRECTORY_SEPARATOR;

// Path to the "CSE_2024" folder
$cseFolder = __DIR__ . DIRECTORY_SEPARATOR . 'CSE_2024' . DIRECTORY_SEPARATOR;

// Moving the uploaded image to the "images" folder
move_uploaded_file($_FILES["image"]["tmp_name"], $imagesFolder . $image);

                
            }
            $sql = "insert into tblstudent(StudentName,StudentEmail,StudentClass,Gender,BD,DOB,StuID,FatherName,MotherName,ContactNumber,AltenateNumber,Address,UserName,Password,Image,city,pincode,state,country,DateofAdmission,dept,tcl,cc,role, areYouPlaced)values(:stuname,:stuemail,:stuclass,:gender,:bd,:dob,:stuid,:fname,:mname,:connum,:altconnum,:address,:uname,:password,:image,:cty,:pc,:state,:ctr,:poy,:dpt,:tcl,:cc,:role,:areYouPlaced)";
            $query = $dbh->prepare($sql);
            $query->bindParam(':stuname', $stuname, PDO::PARAM_STR);
            $query->bindParam(':stuemail', $stuemail, PDO::PARAM_STR);
            $query->bindParam(':stuclass', $stuclass, PDO::PARAM_STR);
            $query->bindParam(':gender', $gender, PDO::PARAM_STR);
            $query->bindParam(':bd', $bd, PDO::PARAM_STR);
            $query->bindParam(':dob', $dob, PDO::PARAM_STR);
            $query->bindParam(':stuid', $stuid, PDO::PARAM_STR);
            $query->bindParam(':fname', $fname, PDO::PARAM_STR);
            $query->bindParam(':mname', $mname, PDO::PARAM_STR);
            $query->bindParam(':connum', $connum, PDO::PARAM_STR);
            $query->bindParam(':altconnum', $altconnum, PDO::PARAM_STR);
            $query->bindParam(':address', $address, PDO::PARAM_STR);
            $query->bindParam(':uname', $uname, PDO::PARAM_STR);
            $query->bindParam(':password', $password, PDO::PARAM_STR);
            $query->bindParam(':image', $image, PDO::PARAM_STR);
            $query->bindParam(':cty', $cty, PDO::PARAM_STR);
            $query->bindParam(':pc', $pc, PDO::PARAM_STR);
            $query->bindParam(':state', $state, PDO::PARAM_STR);
            $query->bindParam(':ctr', $ctr, PDO::PARAM_STR);
            $query->bindParam(':poy', $poy, PDO::PARAM_STR);
            $query->bindParam(':dpt', $dpt, PDO::PARAM_STR);
            $query->bindParam(':tcl', $tcl, PDO::PARAM_STR);
            $query->bindParam(':cc', $cc, PDO::PARAM_STR);
            $query->bindParam(':role', $role, PDO::PARAM_STR);
            $query->bindParam(':areYouPlaced', $areYouPlaced, PDO::PARAM_STR);
            $query->execute();
            $LastInsertId = $dbh->lastInsertId();
            if ($LastInsertId > 0) {
                echo '<script>alert("Student has been added.")</script>';
                echo "<script>window.location.href ='add-students.php'</script>";
            } else {
                echo '<script>alert("Something Went Wrong. Please try again")</script>';
            }
        }
    } else {
        echo "<script>alert('Username or Student Id  already exist. Please try again');</script>";
    }
}
?>
<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script>
    function fetchLocationDetails() {
        var pincode = document.getElementsByName("pc")[0].value;

        fetch(`https://api.postalpincode.in/pincode/${pincode}`)
            .then((response) => response.json())
            .then((data) => {
                if (data && data[0] && data[0].PostOffice && data[0].PostOffice[0]) {
                    var city = data[0].PostOffice[0].District;
                    var state = data[0].PostOffice[0].State;
                    var country = "India"; // Assuming it's always India based on the API

                    document.getElementsByName("cty")[0].value = city;
                    document.getElementsByName("state")[0].value = state;
                    document.getElementsByName("ctr")[0].value = country;
                }
            })
            .catch((error) => console.error('Error fetching location details:', error));
    }

    function showCompanyRoleFields() {
        document.getElementById("companyField").style.display = "block";
        document.getElementById("roleField").style.display = "block";
    }

    function hideCompanyRoleFields() {
        document.getElementById("companyField").style.display = "none";
        document.getElementById("roleField").style.display = "none";
    }
</script>

<style>
    /* Gradient background */
    body {
        background: linear-gradient(135deg, #6A11CB, #2575FC, #A32BEB);
        font-family: Arial, sans-serif;
    }

    h2::before {
        content: "\2022"; /* Unicode for bullet character */
        display: inline-block;
        width: 20px; /* Adjust the width of the bullet */
        text-align: center; /* Center the bullet vertically */
        margin-right: 10px; /* Adjust the spacing between the bullet and the text */
    }

    /* Main container */
    .main-panel {
        background-color: #fff;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    /* Page header */
    .page-header {
        margin-bottom: 20px;
    }

    /* Form container */
    .form-container {
        background-color: #f8f9fa;
        padding: 20px;
        border-radius: 10px;
    }

    /* Form group */
    .form-group {
        margin-bottom: 20px;
    }

    /* Form labels */
    .form-group label {
        font-weight: bold;
        color: #b22222
    }

    /* Form inputs */
    .form-control {
        width: 100%;
        padding: 10px;
        border: 1px solid #ced4da;
        border-radius: 5px;
        transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
    }

    /* Form inputs when focused */
    .form-control:focus {
        border-color: #4A00E0;
        outline: 0;
        box-shadow: 0 0 0 0.2rem rgba(74, 0, 224, 0.25);
    }

    /* Submit button */
    .btn-primary {
        background-color: #4A00E0;
        color: #fff;
        border: none;
        border-radius: 5px;
        padding: 10px 20px;
        cursor: pointer;
        transition: background-color 0.15s ease-in-out;
    }

    /* Submit button hover state */
    .btn-primary:hover {
        background-color: #8E2DE2;
    }

    /* Additional styling for the form */
    .form-title {
        font-size: 24px;
        margin-bottom: 20px;
        color: #b22222;
    }

    .grid-margin {
        margin-bottom: 20px;
    }

    .companyRoleFields {
        display: none;
    }
/* Reset button */



</style>
<div class="main-panel">
    <div class="content-wrapper">
        <div class="page-header" style="text-align: center;">
            <h1 class="page-title" style="font-weight: bold; color: #4B0082;"> Reminiscence - Data Form </h1>
        </div>

        <div class="row">
            <div class="col-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <form class="forms-sample row" method="post" enctype="multipart/form-data">
                            <h2 class="col-md-12">Personal details</h2>
                            <div class="form-group col-md-6">
                                <label for="exampleInputName1">Student Full Name</label>
                                <input type="text" name="stuname" value="" class="form-control" pattern="[a-zA-Z]+\s[a-zA-Z]+\s[a-zA-Z]+" oninput="removeNumbers(event)" required>
                            </div>


                            <script>
                                function removeNumbers(event) {
                                    // Get the input value
                                    var inputValue = event.target.value;

                                    // Remove any numbers from the input value
                                    var cleanedValue = inputValue.replace(/[0-9]/g, '');

                                    // Set the cleaned value as the input value
                                    event.target.value = cleanedValue;
                                }
                            </script>

                            <div class="form-group col-md-6">
                                <label for="exampleInputName1">Student Email</label>
                                <input type="text" name="stuemail" value="" class="form-control" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" title="Please enter a valid email address in the format name@example.com" required>
                            </div>


                            <div class="form-group col-md-6">
                                <label for="exampleInputEmail3">Student Class</label>
                                <select name="stuclass" class="form-control" required>
                                    <option value="">Select Class</option>
                                    <?php

                                    $sql2 = "SELECT * from    tblclass ";
                                    $query2 = $dbh->prepare($sql2);
                                    $query2->execute();
                                    $result2 = $query2->fetchAll(PDO::FETCH_OBJ);

                                    foreach ($result2 as $row1) {
                                        ?>
                                        <option value="<?php echo htmlentities($row1->ID); ?>"><?php echo htmlentities($row1->ClassName); ?> <?php echo htmlentities($row1->Section); ?></option>
                                    <?php } ?>
                                </select>
                            </div>

                            <div class="form-group col-md-6">
                                <label>Gender</label>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="gender" id="male" value="Male" required>
                                    <label class="form-check-label" for="Male">Male</label>
                                </div>

                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="gender" id="female" value="Female">
                                    <label class="form-check-label" for="Female">Female</label>
                                </div>


                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="gender" id="other" value="Other">
                                    <label class="form-check-label" for="other">Other</label>
                                </div>
                            </div>

                            <div class="form-group col-md-6">
                                <label for="exampleInputName1">Blood Group</label>
                                <select name="bd" value="" class="form-control" required>
                                    <option value="">Choose Blood group</option>
                                    <option value="A Positive">A Positive</option>
                                    <option value="B Positive">B Positive</option>
                                    <option value="AB Positive">AB Positive</option>
                                    <option value="O Positive">O Positive</option>
                                    <option value="A Negative">A Negative</option>
                                    <option value="B Negative">B Negative</option>
                                    <option value="AB Negative">AB Negative</option>
                                    <option value="O Negative">O Negative</option>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="exampleInputName1">Date of Birth</label>
                                <input type="date" name="dob" value="" class="form-control" max="<?php echo date('Y-m-d'); ?>">
                            </div>


                            <div class="form-group col-md-6">
                                <label for="exampleInputName1">Student GRN</label>
                                <input type="text" name="stuid" value="" class="form-control" pattern="\d{2}[a-zA-Z]{4}\d{5}" title="Please enter a valid GRN in the format YYxxxxYYYYY">
                            </div>


                            <div class="form-group col-md-6">
                                <label for="exampleInputName1">Student Photo</label>
                                <input type="file" name="image" value="" class="form-control">
                            </div>
                            <h2 class="col-md-12">Parents/Guardian's details</h2>
                            <div class="form-group col-md-6">
                                <label for="exampleInputName1">Father's Name</label>
                                <input type="text" name="fname" value="" class="form-control" pattern="[a-zA-Z]+" oninput="removeNumbers(event)">
                            </div>

                            <div class="form-group col-md-6">
                                <label for="exampleInputName1">Mother's Name</label>
                                <input type="text" name="mname" value="" class="form-control" pattern="[a-zA-Z]+" oninput="removeNumbers(event)">
                            </div>


                            <div class="form-group col-md-6">
                                <label for="exampleInputName1"> Student Contact Number</label>
                                <input type="text" name="connum" value="" class="form-control" maxlength="10" onkeypress="return onlyNumbers(event)" title="Please enter a valid contact number (digits only)">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="exampleInputName1">Parent's Contact Number</label>
                                <input type="text" name="altconnum" value="" class="form-control" maxlength="10" onkeypress="return onlyNumbers(event)" title="Please enter a valid contact number (digits only)">
                            </div>
                            <div class="form-group col-md-12">
                                <label for="exampleInputName1">Address</label>
                                <textarea name="address" class="form-control"></textarea>
                            </div>


                            <div class="form-group col-md-6">
                                <label for="exampleInputName1">Pin-code</label>
                                <input type="text" name="pc" value="" class="form-control" oninput="fetchLocationDetails()">
                            </div>


                            <div class="form-group col-md-6">
                                <label for="exampleInputName1">City</label>
                                <input type="text" name="cty" value="" class="form-control">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="exampleInputName1">State</label>
                                <input type="text" name="state" value="" class="form-control">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="exampleInputName1">Country</label>
                                <input type="text" name="ctr" value="" class="form-control">
                            </div>
                            <h2 class="col-md-12">Academic details</h2>
                            <div class="form-group col-md-6">
    <label for="exampleInputName1">Pass-out year</label>
    <input type="text" id="datepicker" class="form-control" name="poy" readonly>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>
$(function() {
    $("#datepicker").datepicker({
        changeMonth: true,
        changeYear: true,
        yearRange: "2023:2090",
        dateFormat: "yy",
        onClose: function(dateText, inst) {
            var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
            $(this).datepicker('setDate', new Date(year, 1));
        }
    });
});
</script>
                            <div class="form-group col-md-6">
                                <label for="exampleInputName1">Department</label>
                                <select name="dpt" value="" class="form-control">
                                    <option value="">Choose department</option>
                                    <option value="cse">CSE</option>
                                    <option value="etc">ENTC</option>
                                    <option value="civ">CIVIL</option>
                                    <option value="me">MECH</option>
                                    <option value="ch">CHEM</option>
                                </select>
                            </div>

                            <div class="form-group col-md-6">
                                <label for="exampleInputName1">Technology Learned:</label>
                                <textarea name="tcl" class="form-control"></textarea>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="exampleInputName1">Are you placed?</label>
                                <div class="form-check">
                                    <input  class="form-check-input" type="radio" name="areYouPlaced" id="placedYes" value="Yes" onclick="showCompanyRoleFields()">
                                    <label class="form-check-label" for="placedYes">Yes</label>
                                </div>
                                <div class="form-check">
                                    <input  class="form-check-input" type="radio" name="areYouPlaced" id="placedNo" value="No" onclick="hideCompanyRoleFields()">
                                    <label class="form-check-label" for="placedNo">No</label>
                                </div>
                            </div>

                            <div id="companyRoleFields">
                                <div class="form-group col-md-6" id="companyField">
                                    <label for="exampleInputName1">Current Company</label>
                                    <input type="text" name="cc" value="" class="form-control">
                                </div>
                                <div class="form-group col-md-6" id="roleField">
                                    <label for="exampleInputName1">Role</label>
                                    <input type="text" name="role" value="" class="form-control">
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary mr-2" name="submit">Add</button>
                            <button type="reset" class="btn btn-light">Reset</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
