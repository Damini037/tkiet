<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['sturecmsaid']==0)) {
  header('location:logout.php');
} else{
                               
}

// Fetch data from the database
$sql = "SELECT tblstudent.*,tblclass.ClassName,tblclass.Section FROM tblstudent join tblclass on tblstudent.StudentClass=tblclass.id where tblclass.ClassName ='Btech MECH' ";
$query = $dbh->prepare($sql);
$query->execute();
$results = $query->fetchAll(PDO::FETCH_ASSOC);

if ($query->rowCount() > 0) {
  // Initialize an empty array to hold the JSON data
  $studentsData = [];

  foreach ($results as $row) {
    // Build an array for each student
    $student = [
      'StudentID' => $row['StuID'],
      'StudentClass' => $row['ClassName'] . ' ' . $row['Section'],
      'StudentName' => $row['StudentName'],
      'Email' => $row['StudentEmail'],
      'PassoutYear' => $row['DateofAdmission'],
      'Gender' => $row['Gender'],
      'BloodGroup' => $row['bd'],
      'DOB' => $row['DOB'],
      'FatherName' => $row['FatherName'],
      'MotherName' => $row['MotherName'],
      'ContactNumber' => $row['ContactNumber'],
      'AltenateNumber' => $row['AltenateNumber'],
      'Address' => $row['Address'],
      'City' => $row['city'],
      'Pincode' => $row['pincode'],
      'State' => $row['state'],
      'Country' => $row['country'],
      'TechnologyLearned' => $row['tcl'],
      'CurrentCompany' => $row['cc'],
      'Role' => $row['role'],
      'Photo' => $row['Image']
    ];

    // Push the student array into the studentsData array
    $studentsData[] = $student;
  }

  // Convert the studentsData array to JSON
  $jsonData = json_encode($studentsData, JSON_PRETTY_PRINT);

  // Save the JSON data to a file
  file_put_contents('student2.json', $jsonData);

  // Output a message indicating the JSON file has been created
  echo 'JSON file created successfully.';
} else {
  echo "<p>No students found.</p>";
}
?>
<a href="Untitled-4.html" class="btn btn-primary">Go to Another Page</a>