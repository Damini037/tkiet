<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Check if a theme is selected
  if (isset($_POST['theme'])) {
    // Store the selected theme in the session
    $_SESSION['theme'] = $_POST['theme'];
  }
}

// Redirect back to the original page
header('Location: ' . $_SERVER['HTTP_REFERER']);
exit;
?>
