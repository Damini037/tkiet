<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['sturecmsaid']==0)) {
  header('location:logout.php');
  } else{
                               
}
?>

<style>
.container-fluid {
  padding: 20px;
  background-color: #f2f2f2;
}

h2 {
  color: #333;
}

form {
  margin-bottom: 20px;
}

select {
  padding: 8px;
  border: 1px solid #ddd;
  border-radius: 4px;
}

button {
  padding: 8px 12px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

button:hover {
  background-color: #0056b3;
}

table {
  width: 100%;
  border-collapse: collapse;
}

th, td {
  padding: 8px;
  border: 1px solid #ddd;
}

th {
  background-color: #007bff;
  font-weight: bold;
  color: white;
}

tr:nth-child(even) {
  background-color: #f9f9f9;
}

tr:hover {
  background-color: #f2f2f2;
}

td {
  color: #333;
}

</style>

<div class="container-fluid">
  <h2>Blood Group Reports</h2>
  <form method="get">
    <label for="blood_group">Search by Blood Group:</label>
    <select name="blood_group" id="blood_group">
      <option value="">-- Select Blood Group --</option>
      <option value="A Positive">A Positive</option>
      <option value="A Negative">A Negative</option>
      <option value="B Positive">B Positive</option>
      <option value="B Negative">B Negative</option>
      <option value="AB Positive">AB Positive</option>
      <option value="AB Negative">AB Negative</option>
      <option value="O Positive">O Positive</option>
      <option value="O Negative">O Negative</option>
    </select>
    <button type="submit">Search</button>
  </form>
  <?php
  if (isset($_GET['blood_group']) && !empty($_GET['blood_group'])) {
    $blood_group = $_GET['blood_group'];
    $sql = "SELECT tblstudent.*,tblclass.ClassName,tblclass.Section FROM tblstudent join tblclass on tblstudent.StudentClass=tblclass.id WHERE tblstudent.bd = :blood_group ";
    $query = $dbh->prepare($sql);
    $query->bindParam(':blood_group', $blood_group, PDO::PARAM_STR);
    $query->execute();
    $results = $query->fetchAll(PDO::FETCH_OBJ);

    if ($query->rowCount() > 0) {
      echo "<table border='1'>";
      echo "<tr><th>Sr.No</th><th>Student Name</th><th>Email</th><th>Contact Number</th><th>Blood Group</th></tr>";
      $count = 1;
      foreach ($results as $row) {
        echo "<tr>";
        echo "<td>" . $count++ . "</td>";
        echo "<td>" . htmlentities($row->StudentName) . "</td>";
        echo "<td>" . htmlentities($row->StudentEmail) . "</td>";
        echo "<td>" . htmlentities($row->ContactNumber) . "</td>";
        echo "<td>" . htmlentities($row->bd) . "</td>";
        echo "</tr>";
      }
      echo "</table>";
    } else {
      echo "<p>No students found with blood group " . htmlentities($blood_group) . ".</p>";
    }
  }
  ?>
</div>
