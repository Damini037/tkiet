<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['sturecmsaid']==0)) {
  header('location:logout.php');
  } else{
  
  ?>

      
     <?php include_once('includes/header.php');?>
      
      <div class="container-fluid page-body-wrapper">
        
      <?php include_once('includes/sidebar.php');?>
        
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title"> Reminiscence-one step ahead </h3>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Reminiscence-one step ahead </li>
                </ol>
              </nav>
            </div>
            <div class="row">
          
              <div class="col-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title" style="text-align: center;">Departments</h4>
                    <div style="text-align: center;">
                    <a href="cse.php" class="btn btn-primary"> CSE</a>
                    <a href="entc.php" class="btn btn-secondary">ENTC</a>
                    <a href="civil.php" class="btn btn-success">CIVIL</a>
                    <a href="mech.php" class="btn btn-danger">MECH</a>
                    <a href="chem.php" class="btn btn-warning">CHEM</a>
      </div>
      <div class="col-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title" style="text-align: center;">Reports</h4>
                    <div style="text-align: center;">
                    <a href="blood.php" class="btn btn-primary"> Blood Group reports</a>
                    
                    <a href="place.php" class="btn btn-success">Student Placements</a>
                    
      </div>
                    
                  </div>
                </div>
              </div>
            </div>
          </div>
          
         <?php include_once('includes/footer.php');?>
          
        </div>
        
      </div>
      
    </div>
    
    <?php }  ?>
