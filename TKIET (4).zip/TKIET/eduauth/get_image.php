<?php
// Get the filename from the query parameter
$filename = $_GET['filename'];

// Define the path to the image file
$imagePath = 'assets/images/CSE_2024/' . $filename;

// Check if the file exists
if (file_exists($imagePath)) {
    // Get the MIME type of the image
    $mime = mime_content_type($imagePath);

    // Set the Content-Type header based on the MIME type
    header('Content-Type: ' . $mime);

    // Output the image file
    readfile($imagePath);
} else {
    // Return an error image or message if the file doesn't exist
    // For example:
    // header('Content-Type: image/png');
    // readfile('path/to/default-image.png');
    echo 'Image not found';
}
?>
